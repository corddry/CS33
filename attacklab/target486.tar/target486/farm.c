/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_496()
{
    return 1488154247U;
}

unsigned getval_335()
{
    return 3629348450U;
}

void setval_435(unsigned *p)
{
    *p = 3281049789U;
}

unsigned getval_421()
{
    return 3284633928U;
}

void setval_241(unsigned *p)
{
    *p = 3251079496U;
}

void setval_133(unsigned *p)
{
    *p = 3277329283U;
}

unsigned getval_304()
{
    return 2428995912U;
}

unsigned addval_378(unsigned x)
{
    return x + 3284633944U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_187(unsigned *p)
{
    *p = 2447411528U;
}

unsigned getval_407()
{
    return 3286272344U;
}

void setval_272(unsigned *p)
{
    *p = 3281047947U;
}

void setval_164(unsigned *p)
{
    *p = 3465115368U;
}

unsigned getval_127()
{
    return 3531919753U;
}

unsigned getval_132()
{
    return 3223900553U;
}

unsigned getval_173()
{
    return 2430632264U;
}

void setval_397(unsigned *p)
{
    *p = 3527986825U;
}

unsigned addval_316(unsigned x)
{
    return x + 3348156041U;
}

void setval_199(unsigned *p)
{
    *p = 3263766814U;
}

void setval_287(unsigned *p)
{
    *p = 2429452794U;
}

void setval_322(unsigned *p)
{
    *p = 2446231967U;
}

unsigned addval_169(unsigned x)
{
    return x + 3223372427U;
}

unsigned getval_275()
{
    return 3348152969U;
}

unsigned addval_445(unsigned x)
{
    return x + 2425406089U;
}

unsigned getval_331()
{
    return 3281112713U;
}

void setval_380(unsigned *p)
{
    *p = 2425537161U;
}

void setval_400(unsigned *p)
{
    *p = 2425409945U;
}

void setval_292(unsigned *p)
{
    *p = 2425541001U;
}

unsigned getval_112()
{
    return 3286272328U;
}

unsigned addval_385(unsigned x)
{
    return x + 3286276424U;
}

unsigned addval_410(unsigned x)
{
    return x + 3374371209U;
}

unsigned addval_229(unsigned x)
{
    return x + 3767093328U;
}

unsigned getval_189()
{
    return 3224949128U;
}

unsigned addval_338(unsigned x)
{
    return x + 2497743176U;
}

unsigned getval_434()
{
    return 3674787465U;
}

unsigned getval_484()
{
    return 3229926057U;
}

unsigned addval_383(unsigned x)
{
    return x + 3268315433U;
}

unsigned addval_328(unsigned x)
{
    return x + 2425409921U;
}

unsigned addval_242(unsigned x)
{
    return x + 2430634248U;
}

void setval_399(unsigned *p)
{
    *p = 3281306249U;
}

unsigned getval_403()
{
    return 2428666331U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
